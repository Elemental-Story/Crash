package elemental.story.core.commands;

import java.util.ArrayList;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;



public class FeedCommands implements CommandExecutor
{

	String elemental_Prefix = "��7�m��a���F���y��7�n";
	
	
	//Map<Player, Boolean> feed_true_not = (Map<Player, Boolean>) new HashMap();
	
	@SuppressWarnings("unlikely-arg-type")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String string, String[] args) 
	{
		Player player = (Player) sender;
		
		if (sender instanceof Player) {

			// do something
		} else {
			sender.sendMessage(elemental_Prefix + "��c�u�����a�~��ϥΦ����O");
			return false;
		}
		
		
		
		
		ArrayList<Player> feed_true_not = new ArrayList<>();
		if (cmd.equals("feed") && player.hasPermission("elemental.story.feed")) 
		{
			player.addPotionEffect(new PotionEffect(PotionEffectType.SATURATION, 1, 1));
			feed_true_not.add(player);
		}
		else if(cmd.equals("feed") && player.hasPermission("elemental.story.feed") && feed_true_not.contains(player) )	
		{
			player.removePotionEffect(PotionEffectType.SATURATION);
			feed_true_not.remove(player);
		}
		else
		{
			player.sendMessage(elemental_Prefix + "��c�z���v������");  
		}
		
		return false;
	}

}
